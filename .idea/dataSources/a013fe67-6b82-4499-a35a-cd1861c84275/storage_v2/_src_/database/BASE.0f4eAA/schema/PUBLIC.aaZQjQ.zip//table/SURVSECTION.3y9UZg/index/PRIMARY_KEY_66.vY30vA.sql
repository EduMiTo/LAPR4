create unique index PRIMARY_KEY_66
    on SURVSECTION (IDENTIFIER);

