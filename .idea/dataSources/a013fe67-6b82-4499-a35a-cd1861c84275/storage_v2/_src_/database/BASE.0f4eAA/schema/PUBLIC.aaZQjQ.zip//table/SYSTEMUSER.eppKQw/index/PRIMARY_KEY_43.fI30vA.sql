create unique index PRIMARY_KEY_43
    on SYSTEMUSER (USERNAME);

