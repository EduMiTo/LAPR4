create unique index PRIMARY_KEY_F
    on AGV (AGVIDENTIFIER);

