create unique index PRIMARY_KEY_3D
    on SHOPPINGCARTLINE (ID);

