create unique index PRIMARY_KEY_7C
    on ROLESET (PK);

