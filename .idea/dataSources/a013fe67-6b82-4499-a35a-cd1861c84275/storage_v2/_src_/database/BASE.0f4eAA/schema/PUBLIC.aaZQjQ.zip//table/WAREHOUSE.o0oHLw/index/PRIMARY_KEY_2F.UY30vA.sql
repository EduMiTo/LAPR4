create unique index PRIMARY_KEY_2F
    on WAREHOUSE (ID);

