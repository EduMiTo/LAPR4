create unique index PRIMARY_KEY_A
    on SECTION (AISLE_ID, ROWID);

