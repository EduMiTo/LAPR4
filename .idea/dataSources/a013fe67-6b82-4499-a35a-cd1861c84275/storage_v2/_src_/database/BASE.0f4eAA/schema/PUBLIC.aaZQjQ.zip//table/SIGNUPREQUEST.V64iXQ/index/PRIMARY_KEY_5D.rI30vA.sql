create unique index PRIMARY_KEY_5D
    on SIGNUPREQUEST (USERNAME);

