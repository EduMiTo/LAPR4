create unique index PRIMARY_KEY_92
    on SURVEY (SURVEYIDENTIFIER);

