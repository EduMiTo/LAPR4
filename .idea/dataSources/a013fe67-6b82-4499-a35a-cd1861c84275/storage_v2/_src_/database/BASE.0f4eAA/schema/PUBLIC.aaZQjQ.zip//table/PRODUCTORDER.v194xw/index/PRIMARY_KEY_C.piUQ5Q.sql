create unique index PRIMARY_KEY_C
    on PRODUCTORDER (ID);

