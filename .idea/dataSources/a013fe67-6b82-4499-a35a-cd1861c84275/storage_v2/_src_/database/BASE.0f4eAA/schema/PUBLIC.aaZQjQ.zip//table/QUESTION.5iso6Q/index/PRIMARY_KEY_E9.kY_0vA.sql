create unique index PRIMARY_KEY_E9
    on QUESTION (IDENTIFIER);

