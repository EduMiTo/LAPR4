create unique index PRIMARY_KEY_E
    on AGVDOCK (ID);

