create unique index PRIMARY_KEY_31
    on CATEGORY (CODE);

